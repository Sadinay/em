Pilot results export: 20 successful genes, 120 successful angles.
Start with machine_validation.md and pilot20.csv (gene IDs and 120-bit genotypes).
The run path is recorded in femm_entry.json.
labels.csv contains 3299 queue rows: 20 succeeded; 3279 incomplete with empty labels.
waveforms.csv contains the 120 computed angle results.
Each angle retains result.json, state.json and artifact_retention.json.
FEM/ANS work files were removed after validation at user request.
Source code and frozen manifests are included for provenance. Original MAT/template, CNN weights, datasets and the Python environment are not included.
checksums.sha256 covers every copied source file, with paths relative to this archive root.
