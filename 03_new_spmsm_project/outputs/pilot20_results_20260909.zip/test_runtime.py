"""Storage failure/recovery and Windows transport regression checks; no FEMM launch."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pilot as p


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.here = Path(self.temp.name)
        self.patch = patch.object(p, "HERE", self.here)
        self.patch.start()
        self.addCleanup(self.patch.stop)
        cfg = p.physical_config()
        self.contract = {"physical": cfg}
        bits = "0" * 120
        gene = p.mapping.genotype_sha256([0] * 120)
        self.folder = self.here / "femm_runs" / p.digest(self.contract) / gene / "angle_29"
        self.folder.mkdir(parents=True)
        p.save(self.folder.parents[1] / "contract.json", self.contract)
        template = p.physical.TEMPLATE_FILE.read_text(encoding="utf8")
        model = p.physical.configure_fem(p.mapping.replace_cell_materials(template, [0] * 120), cfg, 29, 0)
        (self.folder / "model.fem").write_bytes(model.encode("utf8"))
        (self.folder / "model.ans").write_text("synthetic answer, never a physical solve", encoding="utf8")
        self.identity = {"gene_id": gene, "bits": bits, "inner_angle_deg": 29,
                         "rotor_travel_deg": 0, "currents_a": p.physical.phase_currents(cfg, 29, 0),
                         "condition_fingerprint": p.digest(self.contract),
                         "prepared_sha256": p.sha(self.folder / "model.fem")}
        self.result = {**self.identity, "raw_torque_nm": 2.5,
                       "fem_sha256": p.sha(self.folder / "model.fem"),
                       "ans_sha256": p.sha(self.folder / "model.ans")}
        p.save(self.folder / "result.json", self.result)
        p.save(self.folder / "state.json", {**self.identity, "status": "succeeded", "attempts": [],
                                           "result_sha256": p.sha(self.folder / "result.json")})

    def test_pruned_results_remain_valid_and_unrelated_files_survive(self):
        (self.folder / "notes.txt").write_text("keep")
        p.prune_success(self.folder, self.identity)
        self.assertFalse((self.folder / "model.fem").exists())
        self.assertFalse((self.folder / "model.ans").exists())
        self.assertTrue((self.folder / "notes.txt").exists())
        self.assertEqual(p.validate_success(self.folder, self.identity), self.result)
        p.prune_success(self.folder, self.identity)

    def test_missing_model_without_receipt_is_rejected(self):
        (self.folder / "model.ans").unlink()
        with self.assertRaisesRegex(ValueError, "missing without"):
            p.validate_success(self.folder, self.identity)

    def test_corrupt_model_prevents_any_cleanup(self):
        (self.folder / "model.ans").write_text("corruption")
        with self.assertRaisesRegex(ValueError, "ans hash mismatch"):
            p.prune_success(self.folder, self.identity)
        self.assertTrue((self.folder / "model.fem").exists())
        self.assertFalse((self.folder / "artifact_retention.json").exists())

    def test_result_corruption_after_cleanup_is_rejected(self):
        p.prune_success(self.folder, self.identity)
        p.save(self.folder / "result.json", {**self.result, "raw_torque_nm": 0})
        with self.assertRaisesRegex(ValueError, "Result JSON hash"):
            p.validate_success(self.folder, self.identity)

    def test_receipt_is_bound_to_original_result(self):
        p.prune_success(self.folder, self.identity)
        receipt = self.folder / "artifact_retention.json"
        p.save(receipt, {**p.read(receipt), "ans_sha256": "0" * 64})
        state = p.read(self.folder / "state.json")
        p.save(self.folder / "state.json", {**state, "artifact_retention_sha256": p.sha(receipt)})
        with self.assertRaisesRegex(ValueError, "receipt differs"):
            p.validate_success(self.folder, self.identity)

    def test_interrupted_cleanup_resumes_from_receipt(self):
        original_unlink = Path.unlink
        def interrupted(path, *args, **kwargs):
            if path.name == "model.ans":
                raise PermissionError("simulated interruption after first deletion")
            return original_unlink(path, *args, **kwargs)
        with patch.object(Path, "unlink", interrupted):
            with self.assertRaises(PermissionError):
                p.prune_success(self.folder, self.identity)
        self.assertFalse((self.folder / "model.fem").exists())
        self.assertTrue((self.folder / "model.ans").exists())
        self.assertEqual(p.validate_success(self.folder, self.identity), self.result)
        p.prune_success(self.folder, self.identity)
        self.assertFalse((self.folder / "model.ans").exists())

    def test_failed_angle_is_never_cleaned(self):
        state = p.read(self.folder / "state.json")
        p.save(self.folder / "state.json", {**state, "status": "failed"})
        with self.assertRaisesRegex(ValueError, "not successful"):
            p.prune_success(self.folder, self.identity)
        self.assertTrue((self.folder / "model.fem").exists())

    def test_cleanup_outside_run_root_is_rejected(self):
        with patch.object(p, "HERE", self.here / "other_project"):
            with self.assertRaisesRegex(ValueError, "outside pilot"):
                p.prune_success(self.folder, self.identity)
        self.assertTrue((self.folder / "model.fem").exists())

    def test_windows_com_does_not_use_file_transport(self):
        import win32com.client
        import femm
        commands = []
        class FakeCOM:
            def mlab2femm(self, command):
                commands.append(command)
                return "[2.5]" if command.startswith("mo_gapintegral(") else ""
        p.save(self.folder / "state.json", {**self.identity, "status": "pending", "attempts": []})
        with patch.object(femm, "windowsOS", False), patch.object(win32com.client, "DispatchEx", return_value=FakeCOM()):
            result = p.solve_angle(self.folder, self.contract)
        self.assertEqual(result["raw_torque_nm"], 2.5)
        self.assertEqual(result["attempt_number"], 1)
        self.assertIn("mi_analyze(1)", commands)
        self.assertEqual(p.read(self.folder / "state.json")["status"], "succeeded")


if __name__ == "__main__":
    unittest.main()
